// Navbar + scrollbar
let last_pos = 0
const navbar = document.querySelector('.navbar')
const scroll_progess = document.querySelector('#scroll')

window.addEventListener('scroll', () => {
    const current_pos = window.scrollY

    if (current_pos > last_pos && current_pos > 20) {
        navbar.classList.add('hidden')
    } else {
        navbar.classList.remove('hidden')
    }

    last_pos = current_pos

    scroll_progess.style.width = `${current_pos / (document.body.scrollHeight - window.innerHeight) * 100}%`
})


// Past / Present toggle
const toggle = document.querySelector('#toggle')
const timeTitle = document.querySelector('#time_time')
const timeText = document.querySelector('#time_text')
const timeImage = document.querySelector('#time_img')
const timeImage_2 = document.querySelector('#time_img_2')

toggle.addEventListener('change', () => {
    timeTitle.style.opacity = '0'
    timeText.style.opacity = '0'
    timeImage.style.opacity = '0'
    timeImage_2.style.opacity = '0'

    setTimeout(() => {
        if (toggle.checked === false) {
            timeTitle.textContent = 'PAST — The 1980s'

            timeText.textContent =
                "In the past, comsumption in China was nothing like it is now. Under Maoism, rationing coupons were used to allowcate essential goods. Everything was relatively run-down, and state-run shops and wet markets were where you'd go when you want to buy stuff."

            timeImage.classList.remove('hide')
            timeImage_2.classList.add('hide')
        }

        else {
            timeTitle.textContent = 'PRESENT — The 2020s'

            timeText.textContent =
                'Today, people can shop in supermarkets, shopping malls and online. Mobile payments, online shopping platforms and home delivery have made buying goods much more convenient.'

            timeImage.classList.add('hide')
            timeImage_2.classList.remove('hide')
        }
        timeTitle.style.opacity = '1'
        timeText.style.opacity = '1'
        timeImage.style.opacity = '1'
        timeImage_2.style.opacity = '1'
    }, 400)
})

const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.classList.add('show')
        }
    })
}, {
    threshold: 0.2
})

document.querySelectorAll('.reveal').forEach(element => {
    observer.observe(element)
})

const intro = document.querySelector('#intro')

document.addEventListener('scroll', () => {
    const current_pos = window.scrollY
    const max_height = window.innerHeight 

    let progress = Math.min(current_pos / max_height, 1)

    intro.style.opacity = 1 - progress
})

document.querySelectorAll(".card").forEach((card) => {
  card.addEventListener("mousemove", (event) => {
    const rect = card.getBoundingClientRect() 

    const x = (event.clientX - rect.left) / rect.width - 0.5 
    const y = (event.clientY - rect.top) / rect.height - 0.5 

    card.style.transform = `
      perspective(900px)
      rotateX(${(-y * 7).toFixed(2)}deg)
      rotateY(${(x * 9).toFixed(2)}deg)
      translateY(-4px)
    ` 
  }) 

  card.addEventListener("mouseleave", () => {
    card.style.transform = "" 
  }) 
}) 